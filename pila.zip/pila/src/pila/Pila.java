public class Pila {
    private Nodo top;
    private int tamanio;

    public Pila() {
        top = null;
        tamanio = 0;
    }

    public boolean isEmpty() {
        return top == null;
    }

    public int size() {
        return tamanio;
    }

    public Nodo top() {
        return top;
    }

    public Nodo pop() {
        if (isEmpty()) {
            return null;
        }

        Nodo nodoEliminado = top;
        top = top.getSiguiente();
        tamanio--;

        return nodoEliminado;
    }

    public void push(int elemento) {
        Nodo nuevoNodo = new Nodo(elemento, top);
        top = nuevoNodo;
        tamanio++;
    }

    @Override
    public String toString() {
        if (isEmpty()) {
            return "La pila está vacía.";
        }

        StringBuilder sb = new StringBuilder();
        Nodo nodoActual = top;

        while (nodoActual != null) {
            sb.append(nodoActual.getElemento()).append("\n");
            nodoActual = nodoActual.getSiguiente();
        }

        return sb.toString();
    }
}

