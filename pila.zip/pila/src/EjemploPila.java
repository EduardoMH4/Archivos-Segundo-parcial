public class EjemploPila {
    
    public static void main(String[] args) {
        Pila miPila = new Pila();
        System.out.println(miPila.toString());

        miPila.push(3);
        System.out.println("Valor Top: " + miPila.top().getElemento());

        miPila.push(78);
        System.out.println("Valor Top: " + miPila.top().getElemento());

        miPila.push(23);

        System.out.println("***Después de borrado***");
        miPila.pop();
        miPila.push(45);
        miPila.push(89);
        miPila.push(41);

        System.out.println(miPila.toString());
        System.out.println("Valor Top: " + miPila.top().getElemento());
    }
}