import java.util.Arrays;

public class Busqueda {
    
    // Búsqueda secuencial
    public static int busquedaSecuencial(int[] arreglo, int elemento) {
        for (int i = 0; i < arreglo.length; i++) {
            if (arreglo[i] == elemento) {
                return i;
            }
        }
        return -1; // Si el elemento no se encuentra en el arreglo
    }
    
    // Búsqueda binaria (requiere un arreglo ordenado)
    public static int busquedaBinaria(int[] arreglo, int elemento) {
        int izquierda = 0;
        int derecha = arreglo.length - 1;
        
        while (izquierda <= derecha) {
            int medio = (izquierda + derecha) / 2;
            
            if (arreglo[medio] == elemento) {
                return medio;
            } else if (arreglo[medio] < elemento) {
                izquierda = medio + 1;
            } else {
                derecha = medio - 1;
            }
        }
        
        return -1; // Si el elemento no se encuentra en el arreglo
    }
    
    public static void main(String[] args) {
        int[] arreglo = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
        
        int elemento1 = 23;
        int indice1 = busquedaSecuencial(arreglo, elemento1);
        System.out.println("Búsqueda secuencial:");
        if (indice1 != -1) {
            System.out.println("El elemento " + elemento1 + " se encuentra en el índice " + indice1);
        } else {
            System.out.println("El elemento " + elemento1 + " no se encuentra en el arreglo");
        }
        
        int elemento2 = 16;
        int indice2 = busquedaBinaria(arreglo, elemento2);
        System.out.println("\nBúsqueda binaria:");
        if (indice2 != -1) {
            System.out.println("El elemento " + elemento2 + " se encuentra en el índice " + indice2);
        } else {
            System.out.println("El elemento " + elemento2 + " no se encuentra en el arreglo");
        }
    }
}