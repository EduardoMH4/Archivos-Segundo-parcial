import java.util.Random;
import java.util.Scanner;

public class OrdenamientoDeCadenas {
  
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Ingrese el tamaño de la cadena:");
    int tam = scanner.nextInt();
    
    
    System.out.println("Ingrese el rango de los números aleatorios:");
    int range = scanner.nextInt();
    int[] cadena = generarCadenaAleatoria(tam, range);
    
    System.out.println("La cadena aleatoria generada es:");
    imprimirCadena(cadena);
    
    System.out.println("Elija un método de ordenamiento:");
    System.out.println("1. Burbuja");
    System.out.println("2. Selección");
    System.out.println("3. Inserción Directa");
    System.out.println("4. Shell");
    int opcion = scanner.nextInt();
    
    switch (opcion) {
      case 1:
        burbuja(cadena);
        System.out.println("La cadena ordenada por el método de Burbuja es:");
        imprimirCadena(cadena);
        break;
      case 2:
        seleccion(cadena);
        System.out.println("La cadena ordenada por el método de Selección es:");
        imprimirCadena(cadena);
        break;
      case 3:
        insercionDirecta(cadena);
        System.out.println("La cadena ordenada por el método de Inserción Directa es:");
        imprimirCadena(cadena);
        break;
      case 4:
        shell(cadena);
        System.out.println("La cadena ordenada por el método de Shell es:");
        imprimirCadena(cadena);
        break;
      default:
        System.out.println("Opción inválida");
        break;
    }
  }
  
  public static int[] generarCadenaAleatoria(int tam, int range) {
    int[] cadena = new int[tam];
    Random random = new Random();
    for (int i = 0; i < tam; i++) {
      cadena[i] = random.nextInt(range);
    }
    return cadena;
  }
  
  public static void imprimirCadena(int[] cadena) {
    for (int i = 0; i < cadena.length; i++) {
      System.out.print(cadena[i] + " ");
    }
    System.out.println();
  }
  
  public static void burbuja(int[] cadena) {
    int n = cadena.length;
    for (int i = 0; i < n-1; i++) {
      for (int j = 0; j < n-i-1; j++) {
        if (cadena[j] > cadena[j+1]) {
          int temp = cadena[j];
          cadena[j] = cadena[j+1];
          cadena[j+1] = temp;
        }
      }
    }
  }
  
  public static void seleccion(int[] cadena) {
    int n = cadena.length;
    for (int i = 0; i < n-1; i++) {
      int aux = i;
      for (int j = i+1; j < n; j++) {
        if (cadena[j] < cadena[aux]) {
          aux = j;
        }
      }
      int temp = cadena[i];
      cadena[i] = cadena[aux];
      cadena[aux] = temp;
    }
  }
  
 public static void insercionDirecta(int[] cadena) {
    int n = cadena.length;
    for (int i = 1; i < n; i++) {
        int key = cadena[i];
        int j = i - 1;
        while (j >= 0 && cadena[j] > key) {
            cadena[j + 1] = cadena[j];
            j--;
        }
        cadena[j + 1] = key;
    }
    
}
 
 
public static void shell(int[] cadena) {

        int salto, aux, i;
        boolean cambios;
  
        for (salto = cadena.length / 2; salto != 0; salto /= 2) {
            cambios = true;
            while (cambios) {   // Mientras se intercambie algún elemento                                         
                cambios = false;
                for (i = salto; i < cadena.length; i++)   // se da una pasada
                {
                    if (cadena[i - salto] > cadena[i]) {       // y si están desordenados
                        aux = cadena[i];                  // se reordenan
                        cadena[i] = cadena[i - salto];
                        cadena[i - salto] = aux;
                        cambios = true;              // y se marca como cambio.                                   
                    }
                }
            }
        }
  
}


}